package interfaces;

public interface IFly {
	default void fly() {

	}
}
