insert into aircraft (weight, width, height, serialNumber, horizontalSpeed, modelName, baloonVolume) values(150, 2, 3, 12, 50, 'Jobby', 400);
#update aircraft set horizontalSpeed=60, aircraft_id=2 WHERE modelName="Golla";
select * from aircraft;
#delete from aircraft where aircraft_id=2;
#insert into aircraft (weight, width, height, serialNumber, horizontalSpeed, modelName, baloonVolume) values(150, 2, 3, 10, 50, 'Golla', 400);
update aircraft set horizontalSpeed=60, aircraft_id=2 WHERE modelName="Golla";
select * from aircraft;
#delete from aircraft where aircraft_id=2;
SET time_zone = 'Europe/Kiev';