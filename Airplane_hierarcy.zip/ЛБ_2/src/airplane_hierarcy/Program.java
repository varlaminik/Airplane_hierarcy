package airplane_hierarcy;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.TreeSet;

import DoublyLinkedList.DoublyLinkedList;

public class Program {

	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/aircraftdb";


	static final String USER = "root";
	static final String PASS = "";

		public static void main(String[] args) {


			System.out.println("-------- MySQL JDBC Connection Testing ------------");

			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				System.out.println("Where is your MySQL JDBC Driver?");
				e.printStackTrace();
				return;
			}

			System.out.println("MySQL JDBC Driver Registered!");
			Connection connection = null;

			try {
				connection = DriverManager
						.getConnection(DB_URL, USER, PASS+
								"?verifyServerCertificate=false"+
								"&useSSL=false"+
								"&requireSSL=false"+
								"&useLegacyDatetimeCode=false"+
								"&amp"+
								"&serverTimezone=UTC");

			} catch (SQLException e) {
				System.out.println("Connection Failed! Check output console");
				e.printStackTrace();
				return;
			}

			if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
			//connection.close();
		}


			//Connection connection;
			//Driver driver = new Fa

		
		static void Homework2 (){
			Planer planer = new Planer("airbus", 5.555555, 5.5555, 10.00000, 80.000, 12.4000);
	        System.out.println(planer.getHorizontalSpeed());
	        
	        planer.fly();
	        System.out.println();
	        System.out.println(planer.toString());
	        Planer [] planers = new Planer[2];
	        planers [0] = new Planer ("cat", 122.999);
	        planers [1] = new Planer ("dog", 123.999);
	        TreeSet<Planer> planerList = new TreeSet<Planer>();
	        planerList.add(planers [0]);
	        planerList.add(planers [1]);
	        
	        System.out.println();
	        
	        //Array.sort(planers);
	        for(Planer p: planerList) {
	        	System.out.println(p);
	        }
	        System.out.println();
	        
	        ArrayList<Blimp> blimpList = new ArrayList <Blimp>();
	        Blimp zilla = new Blimp ("zilla", 350.50);
	        Blimp golla = new Blimp ("golla", 280.00);
	        
	        blimpList.add(zilla);
	        blimpList.add(golla);
	        for( Blimp b: blimpList) {
	        	System.out.println(b);
	        }
	        
	        System.out.println();
	        
	        BaloonVolumeComparator myVolumeComp = new BaloonVolumeComparator();
	        blimpList.sort(myVolumeComp);
	        for( Blimp b: blimpList) {
	        	System.out.println(b);
	        }
		}
		static void Homework3(){
			DoublyLinkedList<Blimp> BlimpList = new DoublyLinkedList<Blimp>();

			Blimp zilla = new Blimp ("zilla", 350.50);
			Blimp golla = new Blimp ("golla", 280.00);
			Blimp jimmy = new Blimp ("jimmy", 240.00);
			Blimp debrie = new Blimp ("debrie", 280.00);

			BlimpList.addFront(golla);
			BlimpList.addEnd(zilla);
			BlimpList.addAfter(zilla, jimmy);
			BlimpList.addBefore(jimmy, debrie);
			//BlimpList.remove(golla);

			if(BlimpList.contains(golla))
				System.out.println("true");
			//if(BlimpList.contains(zilla))
			//System.out.println("true");
			Object[] arr = new Object[BlimpList.size()];
			arr = BlimpList.toArrayy();


			String [] BlimpString = BlimpList.toStringg();
			for(int i = 0; i< BlimpList.size(); i++) {
				System.out.println(BlimpString[i]);
			}


			BlimpList.clear();

			//String [] BlimpStringg = BlimpList.toStringg();



			//forech(DoublyLinkedList Node: BlimpList)




		}
}

