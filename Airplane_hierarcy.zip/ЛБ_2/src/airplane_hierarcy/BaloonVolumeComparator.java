package airplane_hierarcy;

import java.util.Comparator;

public class BaloonVolumeComparator implements Comparator<Blimp>{
	
	public int compare(Blimp b1, Blimp b2) {
		if (b1.getBaloonVolume() == b2.getBaloonVolume()) {
			return 0;
		}
		if (b1.getBaloonVolume() < b2.getBaloonVolume()) {
			return -1;
			
		}
		else {
			return 1;
		}
	}
}
