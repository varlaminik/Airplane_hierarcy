package airplane_hierarcy;

public abstract class Aircraft {
	private double height;
	private double width;
	private double weight;
	private double horizontalSpeed;
	private double serialNumber;
	private String modelName;
	
	public double getSerialNumber () {
		return serialNumber;
	}
	
	public void setSerialNumber (double serial) {
		this.serialNumber = serial;
	}
	
	public double getHeight () {
		return height;
	}
	public void setHeight (double height) {
		this.height = height;
	}
	
	public void setWidth (double width) {
		this.width = width;
	}
	public double getWidth () {
		return width;
	}
	
	public void setWeight (double weight) {
		this.weight = weight;
	}
	public double getWeight () {
		return weight;
	}
	
	public void setHorizontalSpeed (double speed) {
		this.horizontalSpeed = speed;
	}
	public double getHorizontalSpeed () {
		return horizontalSpeed;
	}
	public void setModelName(String modelName){
		this.modelName = modelName;
	}
	public String getModelName () {
		return modelName;
	}


	public void Display () {

	}
}
