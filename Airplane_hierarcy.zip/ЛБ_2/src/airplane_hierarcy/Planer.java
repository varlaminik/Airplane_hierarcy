package airplane_hierarcy;

import interfaces.IFly;
import java.util.Comparator;

public class Planer extends AircraftWithoutMotor implements IFly, Comparable<Planer>{

	public Planer (String planerModel, double width, double height, double weight, double speed, double power) {
		super.setWidth(width);
		super.setHeight(height);
		super.setWeight(weight);
		super.setHorizontalSpeed(speed);
		super.setMotorPower(power);
		super.setModelName(planerModel);
		
	}
	
	public Planer (String name, double serial) {
		super.setSerialNumber(serial);
		super.setModelName(name);
	}
	
	public void fly() {
		System.out.printf("I can fly");
	}
	/*
	public int compareTo(Planer p) {
		return ((int)super.getWeight()).compareTo(((int)p.getWeight()));
	}
	*/
	@Override
	public String toString () {
		return "Name " + super.getModelName();
	}

	@Override
	public int compareTo(Planer p) {
		// TODO Auto-generated method stub
		if (this.getSerialNumber() == p.getSerialNumber()) {
			return 0;
		} else if (this.getSerialNumber() < p.getSerialNumber()) {
			return -1;
		} else {
			return 1;
		}
		
	}
}
