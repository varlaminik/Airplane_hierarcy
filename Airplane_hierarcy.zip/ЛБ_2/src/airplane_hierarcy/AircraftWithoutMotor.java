package airplane_hierarcy;

public abstract class AircraftWithoutMotor extends Aircraft {
	double motorPower;
	double fuelTankVolume;
	
	public double getMotorPower () {
		return motorPower;
	}
	public void setMotorPower (double power) {
		this.motorPower = power;
	}
	
	public double getfuelTankVoulme () {
		return fuelTankVolume;
	}
}