package airplane_hierarcy;


public class Blimp extends AircraftWithoutMotor {
	
	private int baloonVolume;
	//private Blimp next, prev;
	
	public double getBaloonVolume () {
		return baloonVolume;
	}
	
	public void setBaloonVolume (int volume) {
		this.baloonVolume = volume;
	}
	
	
	public Blimp (String modelName, double weight) {
		super.setWeight(weight);
		super.setModelName(modelName);
	}

	/*
	public Blimp (Blimp aPrev, Blimp aNext, String blimpModel, double volume) {
		prev = aPrev;
		next = aNext;
		this.setBaloonVolume(volume);
		this.blimpModel = blimpModel;
	}
	*/
	
	@Override
	public String toString () {
		return "Name " + super.getModelName() + " " +super.getWeight();
	}

	
	
}
